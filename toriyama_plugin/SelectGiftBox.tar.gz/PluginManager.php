<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Plugin\SelectGiftBox;

use Eccube\Plugin\AbstractPluginManager;
use Eccube\Entity\Master\OrderItemType;
use Eccube\Repository\OrderItemRepository;
use Eccube\Repository\Master\OrderItemTypeRepository;
use Plugin\SelectGiftBox\Entity\Config as plgConfig;
use Plugin\SelectGiftBox\Entity\SelectGiftBoxInfo;
use Plugin\SelectGiftBox\Repository\SelectGiftBoxInfoRepository;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Filesystem\Filesystem;

/**
 * Class PluginManager.
 */
class PluginManager extends AbstractPluginManager
{
    /**
     * install the plugin.
     * 
     * @param array $meta
     * @param ContainerInterface $container
     */
    public function install(array $meta, ContainerInterface $container)
    {
        $em = $container->get('doctrine.orm.entity_manager');

        // 注文種別に登録する値を生成.
        $query = $em->createQueryBuilder()
            ->select('MAX(o.id)')
            ->from('Eccube\\Entity\\Master\\OrderItemType', 'o')
            ->getQuery();
        $maxId = $query->getResult();
        $box_id = $maxId[0][1] + 1;

        // 注文種別に箱代を追加する.
        $orderItemType = new OrderItemType();
        $orderItemType->setId($box_id);
        $orderItemType->setName('箱代');
        $orderItemType->setSortNo($box_id - 1);
        $em->persist($orderItemType);

        // plg_select_gift_box_infoにも注文種別IDを保存.
        $selectGiftBoxInfo = new SelectGiftBoxInfo();
        $selectGiftBoxInfo->setName('order_item_type_id');
        $selectGiftBoxInfo->setValue($box_id);
        $em->persist($selectGiftBoxInfo);

        // configにデフォルトの値を追加する.
        $config = new plgConfig();
        $config->setName('自宅用');
        $config->setPrice(0);
        $em->persist($config);
        $em->flush();
    }

    /**
     * Uninstall the plugin.
     *
     * @param array $meta
     * @param ContainerInterface $container
     */
    public function uninstall(array $meta, ContainerInterface $container)
    {
        $em = $container->get('doctrine.orm.entity_manager');

        // 箱代の注文種別IDを取得.
        $selectGiftBoxInfoRepository = $container->get(SelectGiftBoxInfoRepository::class);
        $orderItemTypeId = $selectGiftBoxInfoRepository->getValue('order_item_type_id');

        // 注文種別の箱代を削除.
        $orderItemTypeRepository = $container->get(OrderItemTypeRepository::class);
        $orderItemType = $orderItemTypeRepository->findOneBy(array('id' => $orderItemTypeId));
        $em->remove($orderItemType);

        // 注文詳細の中で「箱代」を削除.
        $orderItemRepository = $container->get(OrderItemRepository::class);
        $orderItems = $orderItemRepository->findBy(array('OrderItemType' => $orderItemTypeId));
        foreach ($orderItems as $orderItem) {
            $em->remove($orderItem);
        }
        
        $em->flush();
    }

    /**
     * @param array $meta
     * @param ContainerInterface $container
     */
    public function enable(array $meta, ContainerInterface $container)
    {
    }

    /**
     * @param array $meta
     * @param ContainerInterface $container
     */
    public function disable(array $meta, ContainerInterface $container)
    {
    }
}
