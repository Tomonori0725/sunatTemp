<?php

namespace Plugin\SelectGiftBox\Controller\Admin;

use Eccube\Controller\AbstractController;
use Plugin\SelectGiftBox\Entity\Config;
use Plugin\SelectGiftBox\Form\Type\Admin\ConfigType;
use Plugin\SelectGiftBox\Form\Type\Admin\ConfigEditType;
use Plugin\SelectGiftBox\Repository\ConfigRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class ConfigController extends AbstractController
{
    /**
     * @var ConfigRepository
     */
    protected $configRepository;

    /**
     * ConfigController constructor.
     *
     * @param ConfigRepository $configRepository
     */
    public function __construct(ConfigRepository $configRepository)
    {
        $this->configRepository = $configRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/select_gift_box/config", name="select_gift_box_admin_config")
     * @Template("@SelectGiftBox/admin/config.twig")
     */
    public function index(Request $request)
    {
        $data = array();
        $Configs = $this->configRepository->getAll();

        // var_dump($Configs);
        // exit;

        foreach ($Configs as $config) {
            $data['data'][$config->getId()]['id'] = $config->getId();
            $data['data'][$config->getId()]['name'] = $config->getName();
            $data['data'][$config->getId()]['price'] = $config->getPrice();
        }
        $data['data'][] = array(
            'id'    => '',
            'name'  => '',
            'price' => 0
        );
        $form = $this->createForm(ConfigEditType::class, $data);
        $form->handleRequest($request);

        // 登録が押されたら...
        if ($form->isSubmitted() && $form->isValid()) {
            
        }

        return [
            'form' => $form->createView(),
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/select_gift_box/config/save", name="select_gift_box_admin_config_save")
     * @Template("@SelectGiftBox/admin/config.twig")
     */
    public function save(Request $request)
    {
        if ('POST' === $request->getMethod()) {
            // POSTを取得.
            $posts = $request->get('config_edit');

            // DBに保存.
            foreach ($posts['data'] as $boxType) {
                $data = $this->configRepository->get($boxType['id']);
                if (is_null($data)) {
                    if ($boxType['name'] !== '') {
                        // 新規登録.
                        $data = new Config();
                        $data->setName($boxType['name']);
                        $data->setPrice($boxType['price']);
                        $this->entityManager->persist($data);
                    }
                }
                elseif ($boxType['name'] === '') {
                    // 削除.
                    $this->entityManager->remove($data);
                } else {
                    // 更新.
                    $data->setName($boxType['name']);
                    $data->setPrice($boxType['price']);
                }
                $this->entityManager->flush();
            }

            return $this->redirectToRoute('select_gift_box_admin_config');
        }
    }
}
