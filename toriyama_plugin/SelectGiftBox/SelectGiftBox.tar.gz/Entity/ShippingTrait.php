<?php

namespace Plugin\SelectGiftBox\Entity;

use Doctrine\ORM\Mapping as ORM;
use Eccube\Annotation\EntityExtension;
use Plugin\SelectGiftBox\Entity\Config;

/**
  * @EntityExtension("Eccube\Entity\Shipping")
 */
trait ShippingTrait
{
  /**
   * @var string
   *
   * @ORM\ManyToOne(targetEntity="Plugin\SelectGiftBox\Entity\Config")
   * @ORM\JoinColumns({
   *   @ORM\JoinColumn(name="gift_box_id", referencedColumnName="id")
   * })
   */
  public $gift_box_id;

  /**
   * @return string
   */
  public function getGiftBoxId()
  {
      return $this->gift_box_id;
  }

  /**
   * @param Config $gift_box_id
   *
   * @return $this
   */
  public function setGiftBoxId(Config $gift_box_id)
  {
      $this->gift_box_id = $gift_box_id;

      return $this;
  }

}
