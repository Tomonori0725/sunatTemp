<?php

namespace Plugin\SelectGiftBox\Form\Type\Admin;

use Plugin\SelectGiftBox\Entity\Config;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

use Symfony\Component\Form\Extension\Core\Type\CollectionType;

class ConfigEditType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('data', CollectionType::class, array(
                'entry_type' => ConfigType::class,
                'allow_add' => true,
                'allow_delete' => true,
                'prototype' => true,
            ));

    }

}
