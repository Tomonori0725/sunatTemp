<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Plugin\SelectGiftBox\Form\Extension;

use Eccube\Common\EccubeConfig;
use Symfony\Component\Form\AbstractTypeExtension;

use Plugin\SelectGiftBox\Entity\Config;

use Eccube\Repository\OrderItemRepository;
use Plugin\SelectGiftBox\Repository\ConfigRepository;

use Eccube\Form\Type\Shopping\ShippingType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Validator\Constraints\NotBlank;

/**
 * Class ShippingTypeExtension.
 */
class ShippingTypeExtension extends AbstractTypeExtension
{
    /**
     * @var EccubeConfig
     */
    protected $eccubeConfig;

    /**
     * @var Config
     */
    protected $config;

    /**
     * @var ConfigRepository
     */
    protected $configRepository;

    /**
     * @var OrderItemRepository
     */
    protected $orderItemRepository;

    /**
     * ShippingType constructor.
     *
     * @param EccubeConfig $eccubeConfig
     * @param Config $config
     * @param ConfigRepository $configRepository
     * @param OrderItemRepository $orderItemRepository
     */
    public function __construct(
        EccubeConfig $eccubeConfig,
        Config $config,
        ConfigRepository $configRepository,
        OrderItemRepository $orderItemRepository
    ){
        $this->eccubeConfig = $eccubeConfig;
        $this->config = $config;
        $this->configRepository = $configRepository;
        $this->orderItemRepository = $orderItemRepository;
    }


    /**
     * buildForm.
     *
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        // 箱代のラジオボタンを生成.
        $builder->addEventListener(
            FormEvents::PRE_SET_DATA,
            function (FormEvent $event) {
                $giftBoxChoice = array();
                $Shipping = $event->getData();

                // ラジオボタンの値を決定.
                $giftBoxData = 1;
                if (array_key_exists('select_gift_box', $_SESSION) 
                && array_key_exists($Shipping->getId(), $_SESSION['select_gift_box'])) {
                    $giftBoxData = $_SESSION['select_gift_box'][$Shipping->getId()];
                }

                // マスターデータを取得.
                $giftBoxTypes = $this->configRepository->findAll();
                foreach($giftBoxTypes as $giftBoxType) {
                    $giftBoxChoice[$giftBoxType->getName()] = $giftBoxType->getId();
                }

                // フォームを作成.
                $form = $event->getForm();
                $form->add('gift_box', ChoiceType::class, [
                    'choices'  => $giftBoxChoice,
                    'expanded' => true,
                    'multiple' => false,
                    'mapped'   => false,
                    'data'     => $giftBoxData,
                ]);
                $form->add('shipping_id', HiddenType::class, [
                    'data'   => $Shipping->getId(),
                    'mapped' => false,
                ]);

            }
        );
    }

    public function getExtendedType()
    {
        return ShippingType::class;
    }

}
