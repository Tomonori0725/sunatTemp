<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Plugin\SelectGiftBox;

use Eccube\Plugin\AbstractPluginManager;
use Eccube\Entity\Master\OrderItemType;
use Plugin\SelectGiftBox\Entity\Config as plgConfig;
use Eccube\Repository\Master\OrderItemTypeRepository;
use Plugin\SelectGiftBox\Repository\ConfigRepository;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class PluginManager.
 */
class PluginManager extends AbstractPluginManager
{

    /**
     * install the plugin.
     * 
     * @param array $meta
     * @param ContainerInterface $container
     */
    public function install(array $meta, ContainerInterface $container)
    {
        $em = $container->get('doctrine.orm.entity_manager');

        $orderItemTypeRepository = $container->get(OrderItemTypeRepository::class);
        $itemOrderType = $orderItemTypeRepository->findBy(array('id' => 100));

        if (is_null($itemOrderType)) {
            // order_item_typeに箱代を追加する.
            $orderItemType = new OrderItemType();
            $orderItemType->setId(100);
            $orderItemType->setName('箱代');
            $orderItemType->setSortNo(100);
            $em->persist($orderItemType);
        }

        // configにデフォルトの値を追加する.
        $config = new plgConfig();
        $config->setName('自宅用');
        $config->setPrice(0);
        $em->persist($config);

        $em->flush();
    }

    /**
     * Uninstall the plugin.
     *
     * @param array $meta
     * @param ContainerInterface $container
     */
    public function uninstall(array $meta, ContainerInterface $container)
    {
    }

    /**
     * @param array $meta
     * @param ContainerInterface $container
     */
    public function enable(array $meta, ContainerInterface $container)
    {
    }

    /**
     * @param array $meta
     * @param ContainerInterface $container
     */
    public function disable(array $meta, ContainerInterface $container)
    {
    }

}
